import ply.lex as lex

# Definición de tokens
tokens = (
    'NUMERO',
    'MAS',
    'MENOS',
    'POR',
    'DIVIDIDO',
    'PARENTESIS_IZQ',
    'PARENTESIS_DER',
)

# Expresiones regulares para tokens simples
t_MAS = r'\+'
t_MENOS = r'-'
t_POR = r'\*'
t_DIVIDIDO = r'/'
t_PARENTESIS_IZQ = r'\('
t_PARENTESIS_DER = r'\)'

# Regla para el token NUMERO (números enteros)
def t_NUMERO(t):
    r'\d+'
    t.value = int(t.value)
    return t

# Regla para manejar espacios en blanco (no se almacenan en tokens)
t_ignore = ' \t'

# Regla para manejar saltos de línea (no se almacenan en tokens)
def t_newline(t):
    r'\n+'
    t.lexer.lineno += t.value.count("\n")

# Manejo de errores (tokens no reconocidos)
def t_error(t):
    print("Carácter no válido '%s'" % t.value[0])
    t.lexer.skip(1)

# Crear el analizador léxico
lexer = lex.lex()



# Función para analizar una expresión y retornar los tokens
def analizar_expresion(expresion):
    lexer.input(expresion)
    tokens = []
    while True:
        tok = lexer.token()
        if not tok:
            break
        tokens.append((tok.value, tok.type))
    return tokens
