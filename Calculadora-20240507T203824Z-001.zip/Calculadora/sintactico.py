import ply.yacc as yacc
from lexico import tokens

class Nodo:
    def __init__(self, tipo, valor=None):
        self.tipo = tipo
        self.valor = valor
        self.hijos = []

    def agregar_hijo(self, hijo):
        self.hijos.append(hijo)

precedence = (
    ('left', 'MAS', 'MENOS'),
    ('left', 'POR', 'DIVIDIDO'),
)

def p_expresion_suma_resta(p):
    '''expresion : expresion MAS expresion
                  | expresion MENOS expresion'''
    p[0] = Nodo(tipo='OPERADOR', valor=p[2])
    p[0].agregar_hijo(p[1])
    p[0].agregar_hijo(p[3])

def p_expresion_producto_division(p):
    '''expresion : expresion POR expresion
                  | expresion DIVIDIDO expresion'''
    p[0] = Nodo(tipo='OPERADOR', valor=p[2])
    p[0].agregar_hijo(p[1])
    p[0].agregar_hijo(p[3])

def p_expresion_parentesis(p):
    'expresion : PARENTESIS_IZQ expresion PARENTESIS_DER'
    p[0] = p[2]

def p_expresion_numero(p):
    'expresion : NUMERO'
    p[0] = Nodo(tipo='NUMERO', valor=p[1])

def p_error(p):
    print("Error de sintaxis en '%s'" % p.value)

# Construir el parser
parser = yacc.yacc()

# Función para construir el árbol sintáctico
def construir_arbol_sintactico(tokens):
    return parser.parse(tokens)





