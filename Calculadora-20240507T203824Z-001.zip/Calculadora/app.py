from flask import Flask, render_template, request
from lexico import analizar_expresion

arbol = None

app = Flask(__name__)
last_result = None


@app.route('/calculate')
def calculator():
    return render_template('calculator.html')

@app.route('/ver_arbol')
def arbol():
    global arbol
    if not arbol:
        return render_template('calculator.html')
    return render_template('Arbol.html', arbol=arbol)

@app.route('/calculate', methods=['POST'])
def calculate():
    global last_result  # Mover la declaración global aquí

    expression = request.form['expression']
    global arbol
    arbol = expression
    if not expression.strip():  # Verifica si la expresión está vacía o contiene solo espacios en blanco
        result = last_result if last_result is not None else 0  # Devuelve el último resultado si está disponible, de lo contrario, devuelve 0
        tokens_descripcion = []
    else:
        try:
            # Analizar la expresión y obtener los tokens
            tokens = analizar_expresion(expression)

            # Mapear tipos de token a descripciones
            tipo_descripcion = {
                'NUMERO': 'Número entero',
                'MAS': 'Operador más',
                'MENOS': 'Operador menos',
                'MULTIPLICACION': 'Operador multiplicación',
                'DIVIDIDO': 'Operador división',
                'PARENTESIS_IZQ': 'Paréntesis izquierdo',
                'PARENTESIS_DER': 'Paréntesis derecho'
                # Agrega más mapeos según sea necesario
            }

            # Convertir tipos de token a descripciones
            tokens_descripcion = [(token[0], tipo_descripcion.get(token[1], token[1])) for token in tokens]
            
            # Calcular el resultado de la expresión
            result = eval(expression)

            # Almacenar el resultado en last_result
            last_result = result
        except Exception as e:
            result = "Error: " + str(e)
            tokens_descripcion = []

    return render_template('calculator.html', tokens=tokens_descripcion, result=result)


if __name__ == '__main__':
    app.run(debug=True)





